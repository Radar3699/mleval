# eval_module.py

def my_function():
    print("Hello, world!")
