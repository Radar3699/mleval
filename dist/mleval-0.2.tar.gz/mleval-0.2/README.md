A python package for comprehensive machine learning evaluation.

