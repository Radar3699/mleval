# __init__.py

from .eval_module import my_function
