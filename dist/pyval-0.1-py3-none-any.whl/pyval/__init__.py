# __init__.py

from .mymodule import my_function
